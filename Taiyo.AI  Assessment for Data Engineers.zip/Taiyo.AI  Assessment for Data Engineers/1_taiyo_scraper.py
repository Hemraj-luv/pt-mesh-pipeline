import requests,os,csv,json,re
from bs4 import BeautifulSoup
import math
from isset import getKeys


sess = requests.session()
sess.headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'


def dataextraction(Response,Regex):
    extraction = re.compile(Regex,re.I|re.M|re.S)
    data = extraction.findall(str(Response))
    return data
    
def data_clean(raw_data):
    data1 = re.sub(r'\n+','',raw_data)
    data1 = re.sub(r'\t+','',data1)
    data1 = re.sub(r'\r+','',data1)
    return data1

def download_file(data,html_folder):
  with open(f'{html_folder}\countries.html',mode = 'w',encoding = 'utf-8') as file:
    file.write(str(data))   
    print('file saved successfully in html format ')

def grab_countries_page(url):
    response_data = sess.get(url)
    print('countries page HTTP CODE:',response_data.status_code) 
    if(response_data.status_code == 200) & (response_data.content != ''):
        data = BeautifulSoup(response_data.content,'html.parser')
        download_file(data,html_folder)
        return data
        
def grab_tendor_page(portal_post_link,post_data):
    response_data1 = sess.post(portal_post_link,data=post_data,headers={
                          'content-length': str(len(post_data)),
                          })
    if(response_data1.status_code == 200) & (response_data1.content != ''):
        print(f'HTTP CODE: {response_data1.status_code}',end = ' ')
        data = BeautifulSoup(response_data1.content,'html.parser')
        return data
        
        
def portal_links(portal_page):
    header        = ['Tendor Title', 'Buyer','Country','Country Code','Tender Link']
    counter       = 0 
    csv_data      = []
    regex_countries   = '<ul _ngcontent-c327="" class="portal-links">(.*?)</ul>'
    output_links = dataextraction(portal_page,regex_countries)
    output_links = data_clean(output_links[0]).replace('<!-- -->','')
    
    if(output_links !=''):
        links   = '<li _ngcontent-c327="" class="portal-link"><a _ngcontent-c327="" href="(.*?)">(.*?)</a><div _ngcontent-c327="">(.*?)</div></li>' 
        all_links = dataextraction(output_links,links)
        for tup in all_links:
            portal_link     = tup[0]
            country         = tup[1]
            tender_count    = tup[2]
            tender_count    = int(float(tup[2].replace('Million','').strip())*1000000) if 'Million' in tender_count else tup[2].replace(',','')
            contry_code     = portal_link.split('?') 
            portal_post_link = f'https://opentender.eu/api{contry_code[0]}/tender/search'  #100 records on 1 hit
            print(f'country:{country}, tender_count:{tender_count}, api:{portal_post_link}')
            
            total_pages = math.ceil(int(tender_count)/10)
            for nth_page in range(0,total_pages+1):
                post_data = '{"filters":[],"aggregations":[{"type":"years","field":"lots.awardDecisionDate"}],"stats":[],"lang":"en","from":'+str(nth_page*10)+',"size":10}'
                
                if(portal_post_link !=''):
                    json_data = grab_tendor_page(portal_post_link,post_data)
                    # with open('hem.json',encoding='utf-8',mode='w') as f: f.write(str(json_data));exit();
                    json_data = json.loads(str(json_data))
                    data = json_data['data']['hits']['hits']
                    for each in data:
                        tendor_title        = str(each['title']).strip() if 'title' in getKeys(each) else ''
                        buyer_name          = str(each['buyers'][0]['name']).strip() if 'buyers' in getKeys(each) else ''
                        tendor_id           = str(each['id']).strip() if 'id' in getKeys(each) else ''
                        tendor_link         = 'https://opentender.eu/at/tender/'+tendor_id 
                        country_code        = str(each['country']).strip() if 'country' in getKeys(each) else ''
                        csv_data.append([tendor_title,buyer_name,country,country_code,tendor_link]) 
                        counter+=1
                        
                with open(f'Tendors_details.csv',mode='w+', encoding='UTF8',newline='') as file:
                    writer = csv.writer(file)
                    writer.writerow(header)
                    writer.writerows(csv_data)
                    print(f"{counter} records inserted in CSV File")       
            

if __name__ == '__main__':
  url = 'https://opentender.eu/start'
  
  global html_folder,foldername
  foldername = 'opentender'
  html_folder  = os.getcwd()+f'\{foldername}'
  if not os.path.isdir(html_folder):os.makedirs(html_folder)
  if not os.path.isfile(f'{html_folder}\countries.html'):
    portal_page = grab_countries_page(url)
    portal_links(portal_page)
  else:
   with open(f'{html_folder}\countries.html',mode = 'r',encoding = 'utf-8') as file:
     portal_page = str(file.read())
     print('file exist')
     portal_links(portal_page)  